from django.shortcuts import render
from django.http import HttpResponse
from personas.models import Personas
# Create your views here.

def bienvenido(request):
    no_personas = Personas.objects.count()
    #personas = Personas.objects.all()
    personas = Personas.objects.order_by('id')
    return render(request, 'bienvenido.html', {'no_personas': no_personas, 'personas': personas})

