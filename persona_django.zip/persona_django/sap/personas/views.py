from django.shortcuts import render, redirect
from personas.models import Personas
from personas.forms import PersonaForm
from django.forms  import modelform_factory
# Create your views here.

def detallePersona(request, id):
    persona = Personas.objects.get(pk=id)
    return render(request, 'detalle.html', {'persona': persona })

#PersonaForm = modelform_factory(Personas, exclude=[])

def nuevaPersona(request):
    if request.method == 'POST':
        formaPersona = PersonaForm(request.POST)
        if formaPersona.is_valid():
            formaPersona.save()
            return  redirect('index')

    else:
        formaPersona =  PersonaForm()

    return render(request, 'personas/nuevo.html', {'formaPersona': formaPersona })

def editarPersona(request, id):
    persona = Personas.objects.get(pk=id)
    if request.method == 'POST':
        formaPersona = PersonaForm(request.POST, instance=persona)
        if formaPersona.is_valid():
            formaPersona.save()
            return  redirect('index')

    else:
        formaPersona =  PersonaForm(instance=persona)

    return render(request, 'personas/editar.html', {'formaPersona': formaPersona })

def eliminarPersona(request, id):
    persona = Personas.objects.get(pk=id)
    if persona:
        persona.delete()
    return redirect('index')

