from django.forms import ModelForm, EmailInput
from personas.models import  Personas
from domicilio.models import  Domicilio

class PersonaForm(ModelForm):
    class Meta:
        model = Personas
        fields = '__all__'
        widgets = {

            'email': EmailInput(attrs={'type':'email'})
        }

class DomicilioForm(ModelForm):
    class Meta:
        model = Domicilio
        fields = '__all__'
        widgets = {

            'no_calle': TextInput(attrs={'type':'number'})
        }